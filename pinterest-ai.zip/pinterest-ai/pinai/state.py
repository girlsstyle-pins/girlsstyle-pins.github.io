"""Persistent state kept in data/state.json (committed back to the private repo by the workflows).

Pinterest tokens are stored encrypted with a key derived from PINTEREST_APP_SECRET.
Only the system's own records are kept here (drafts it prepared, decisions, settings);
Pinterest analytics are fetched fresh on every run and never stored.
"""
import base64
import hashlib
import json
import secrets as pysecrets
import time

from cryptography.fernet import Fernet, InvalidToken

from .config import DATA_DIR, secret

STATE_FILE = DATA_DIR / "state.json"
STRATEGY_FILE = DATA_DIR / "strategy.md"
MAX_DRAFTS_KEPT = 300

DEFAULT_STATE = {
    "version": 1,
    "mode": "manual",  # manual | sandbox | live
    "telegram": {"chat_id": None, "offset": 0},
    "account": {},
    "tokens": {},  # env -> encrypted token bundle
    "drafts": [],
    "last_daily_run": None,
    "last_weekly_run": None,
}


def load():
    if STATE_FILE.exists():
        with open(STATE_FILE, encoding="utf-8") as f:
            state = json.load(f)
    else:
        state = {}
    for key, value in DEFAULT_STATE.items():
        if key not in state:
            state[key] = json.loads(json.dumps(value))
    return state


def save(state):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    state["drafts"] = state["drafts"][-MAX_DRAFTS_KEPT:]
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    tmp.replace(STATE_FILE)


def load_strategy():
    if STRATEGY_FILE.exists():
        return STRATEGY_FILE.read_text(encoding="utf-8")
    return "No strategy notes yet. This is the first week of running the account with the AI manager."


def save_strategy(text):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STRATEGY_FILE.write_text(text.strip() + "\n", encoding="utf-8")


# --- token encryption -------------------------------------------------------

def _fernet():
    digest = hashlib.sha256(b"pinterest-ai-state:" + secret("PINTEREST_APP_SECRET").encode()).digest()
    return Fernet(base64.urlsafe_b64encode(digest))


def set_tokens(state, env, bundle):
    raw = json.dumps(bundle).encode()
    state["tokens"][env] = _fernet().encrypt(raw).decode()


def get_tokens(state, env):
    blob = state["tokens"].get(env)
    if not blob:
        return None
    try:
        return json.loads(_fernet().decrypt(blob.encode()))
    except InvalidToken:
        return None


# --- drafts -------------------------------------------------------------------

def new_draft_id(state):
    existing = {d["id"] for d in state["drafts"]}
    while True:
        did = pysecrets.token_hex(3)
        if did not in existing:
            return did


def find_draft(state, draft_id):
    for d in state["drafts"]:
        if d["id"] == draft_id:
            return d
    return None


def now():
    return int(time.time())
