"""Minimal Pinterest API v5 client: OAuth, account, boards, analytics, trends, creating Pins."""
import base64
import datetime as dt
import time
import urllib.parse

import requests

from . import state as st
from .config import redirect_uri, secret

HOSTS = {
    "production": "https://api.pinterest.com/v5",
    "sandbox": "https://api-sandbox.pinterest.com/v5",
}
SCOPES = "boards:read,boards:write,pins:read,pins:write,user_accounts:read"
METRICS = "IMPRESSION,OUTBOUND_CLICK,SAVE,PIN_CLICK"


class PinterestError(RuntimeError):
    def __init__(self, status, message):
        super().__init__(f"Pinterest API {status}: {message}")
        self.status = status


def authorize_url(state_value):
    query = urllib.parse.urlencode({
        "client_id": secret("PINTEREST_APP_ID"),
        "redirect_uri": redirect_uri(),
        "response_type": "code",
        "scope": SCOPES,
        "state": state_value,
    })
    return f"https://www.pinterest.com/oauth/?{query}"


def _basic_auth():
    raw = f"{secret('PINTEREST_APP_ID')}:{secret('PINTEREST_APP_SECRET')}".encode()
    return "Basic " + base64.b64encode(raw).decode()


def _token_request(env, data):
    resp = requests.post(
        HOSTS[env] + "/oauth/token",
        headers={"Authorization": _basic_auth(), "Content-Type": "application/x-www-form-urlencoded"},
        data=data,
        timeout=30,
    )
    if resp.status_code >= 400:
        raise PinterestError(resp.status_code, resp.text[:300])
    body = resp.json()
    now = st.now()
    bundle = {
        "access_token": body["access_token"],
        "refresh_token": body.get("refresh_token"),
        "access_expires_at": now + int(body.get("expires_in", 2592000)),
        "scope": body.get("scope", ""),
    }
    if body.get("refresh_token_expires_at"):
        bundle["refresh_expires_at"] = int(body["refresh_token_expires_at"])
    elif body.get("refresh_token_expires_in"):
        bundle["refresh_expires_at"] = now + int(body["refresh_token_expires_in"])
    else:
        bundle["refresh_expires_at"] = now + 60 * 86400
    return bundle


def exchange_code(env, code):
    return _token_request(env, {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri(),
        "continuous_refresh": "true",
    })


def refresh_if_needed(state, env, force=False):
    """Refresh tokens well before they expire. Returns the bundle or None if not connected."""
    bundle = st.get_tokens(state, env)
    if not bundle:
        return None
    now = st.now()
    access_left = bundle.get("access_expires_at", 0) - now
    refresh_left = bundle.get("refresh_expires_at", 0) - now
    if refresh_left <= 0:
        return None
    if force or access_left < 5 * 86400 or refresh_left < 25 * 86400:
        new = _token_request(env, {"grant_type": "refresh_token", "refresh_token": bundle["refresh_token"]})
        if not new.get("refresh_token"):
            new["refresh_token"] = bundle["refresh_token"]
            new["refresh_expires_at"] = bundle["refresh_expires_at"]
        st.set_tokens(state, env, new)
        bundle = new
    return bundle


class Client:
    def __init__(self, env, access_token):
        self.env = env
        self.base = HOSTS[env]
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {access_token}"})

    @classmethod
    def from_state(cls, state, env):
        bundle = refresh_if_needed(state, env)
        if not bundle:
            return None
        return cls(env, bundle["access_token"])

    def request(self, method, path, **kwargs):
        url = path if path.startswith("http") else self.base + path
        for attempt in range(3):
            resp = self.session.request(method, url, timeout=60, **kwargs)
            if resp.status_code == 429 or resp.status_code >= 500:
                time.sleep(5 * (attempt + 1))
                continue
            break
        if resp.status_code >= 400:
            try:
                message = resp.json().get("message", resp.text)
            except ValueError:
                message = resp.text
            raise PinterestError(resp.status_code, str(message)[:300])
        return resp.json() if resp.content else {}

    # --- account & boards ---

    def user_account(self):
        return self.request("GET", "/user_account")

    def boards(self):
        items, bookmark = [], None
        for _ in range(10):  # sandbox may return empty pages with a bookmark
            params = {"page_size": 100}
            if bookmark:
                params["bookmark"] = bookmark
            data = self.request("GET", "/boards", params=params)
            items.extend(data.get("items", []))
            bookmark = data.get("bookmark")
            if not bookmark:
                break
        return items

    def create_board(self, name, description=""):
        return self.request("POST", "/boards", json={"name": name, "description": description, "privacy": "PUBLIC"})

    def pin(self, pin_id):
        return self.request("GET", f"/pins/{pin_id}")

    def create_pin(self, board_id, title, description, link, alt_text, image_bytes, content_type="image/jpeg"):
        body = {
            "board_id": str(board_id),
            "title": title[:100],
            "description": description[:800],
            "link": link,
            "alt_text": alt_text[:500],
            "media_source": {
                "source_type": "image_base64",
                "content_type": content_type,
                "data": base64.b64encode(image_bytes).decode(),
            },
        }
        return self.request("POST", "/pins", json=body)

    # --- analytics (fetched fresh each time, never stored) ---

    @staticmethod
    def _range(days, end_offset=1):
        end = dt.date.today() - dt.timedelta(days=end_offset)
        start = end - dt.timedelta(days=days - 1)
        return start.isoformat(), end.isoformat()

    def account_summary(self, days=30, end_offset=1):
        start, end = self._range(days, end_offset)
        data = self.request("GET", "/user_account/analytics", params={
            "start_date": start, "end_date": end, "metric_types": METRICS,
        })
        block = data.get("all", data)
        summary = block.get("summary_metrics")
        if not summary:
            summary = {}
            for day in block.get("daily_metrics", []):
                for k, v in (day.get("metrics") or {}).items():
                    if isinstance(v, (int, float)):
                        summary[k] = summary.get(k, 0) + v
        return {"start": start, "end": end, "metrics": summary}

    def top_pins(self, days=30, sort_by="IMPRESSION", limit=10):
        start, end = self._range(days)
        data = self.request("GET", "/user_account/analytics/top_pins", params={
            "start_date": start, "end_date": end, "sort_by": sort_by,
            "metric_types": METRICS, "num_of_pins": limit,
        })
        out = []
        for item in data.get("pins", [])[:limit]:
            pin_id = item.get("pin_id") or item.get("id")
            entry = {"pin_id": pin_id, "metrics": item.get("metrics", {})}
            try:
                details = self.pin(pin_id)
                entry["title"] = details.get("title") or ""
                entry["description"] = (details.get("description") or "")[:200]
                entry["has_link"] = bool(details.get("link"))
            except PinterestError:
                pass
            out.append(entry)
        return out

    def pin_metrics(self, pin_id, days=30):
        start, end = self._range(days)
        data = self.request("GET", f"/pins/{pin_id}/analytics", params={
            "start_date": start, "end_date": end, "metric_types": METRICS,
        })
        block = data.get("all", data)
        return block.get("summary_metrics") or block.get("lifetime_metrics") or {}

    # --- trends ---

    def trending_keywords(self, region, trend_type, interest=None, limit=20):
        params = {"limit": limit, "genders": "female"}
        if interest:
            params["interests"] = interest
        paths = [region, urllib.parse.quote(region, safe="")]
        last_error = None
        for reg in dict.fromkeys(paths):
            for p in (params, {"limit": limit}):
                try:
                    data = self.request("GET", f"/trends/keywords/{reg}/top/{trend_type}", params=p)
                    return [
                        {
                            "keyword": t.get("keyword"),
                            "wow": t.get("pct_growth_wow"),
                            "mom": t.get("pct_growth_mom"),
                            "yoy": t.get("pct_growth_yoy"),
                        }
                        for t in data.get("trends", [])
                    ]
                except PinterestError as e:
                    last_error = e
                    if e.status not in (400, 404):
                        raise
        raise last_error
