"""Telegram Bot API helpers. The bot talks only to the owner's chat."""
import html
import json

import requests

from .config import secret

API = "https://api.telegram.org/bot{token}/{method}"
FILE_API = "https://api.telegram.org/file/bot{token}/{path}"


class TelegramError(RuntimeError):
    pass


def _call(method, files=None, http_timeout=60, **params):
    url = API.format(token=secret("TELEGRAM_BOT_TOKEN"), method=method)
    data = {}
    for k, v in params.items():
        if v is None:
            continue
        data[k] = json.dumps(v) if isinstance(v, (dict, list)) else v
    resp = requests.post(url, data=data, files=files, timeout=http_timeout)
    try:
        body = resp.json()
    except ValueError:
        raise TelegramError(f"Telegram {method}: HTTP {resp.status_code}")
    if not body.get("ok"):
        raise TelegramError(f"Telegram {method}: {body.get('description')}")
    return body["result"]


def esc(text):
    return html.escape(str(text or ""), quote=False)


def keyboard(rows):
    return {"inline_keyboard": [[{"text": t, "callback_data": d} for t, d in row] for row in rows]}


def send_message(chat_id, text, buttons=None, silent=False):
    chunks = [text[i:i + 3900] for i in range(0, len(text), 3900)] or [""]
    result = None
    for i, chunk in enumerate(chunks):
        result = _call(
            "sendMessage",
            chat_id=chat_id,
            text=chunk,
            parse_mode="HTML",
            disable_web_page_preview=True,
            disable_notification=silent,
            reply_markup=keyboard(buttons) if buttons and i == len(chunks) - 1 else None,
        )
    return result


def send_photo(chat_id, png_bytes, caption, buttons=None):  # png_bytes: any JPEG/PNG bytes
    return _call(
        "sendPhoto",
        files={"photo": ("pin.jpg", png_bytes, "image/jpeg")},
        chat_id=chat_id,
        caption=caption[:1024],
        parse_mode="HTML",
        reply_markup=keyboard(buttons) if buttons else None,
    )


def send_document(chat_id, data, filename, caption=""):
    return _call(
        "sendDocument",
        files={"document": (filename, data, "image/jpeg")},
        chat_id=chat_id,
        caption=caption[:1024],
        parse_mode="HTML",
    )


def edit_buttons(chat_id, message_id, buttons=None):
    try:
        _call("editMessageReplyMarkup", chat_id=chat_id, message_id=message_id,
              reply_markup=keyboard(buttons) if buttons else {"inline_keyboard": []})
    except TelegramError:
        pass


def answer_callback(callback_id, text):
    try:
        _call("answerCallbackQuery", callback_query_id=callback_id, text=text[:190])
    except TelegramError:
        pass  # queries older than a few minutes can no longer be answered


def get_updates(offset, wait_seconds=0):
    """Long-poll for new updates. wait_seconds > 0 keeps the request open until something arrives."""
    return _call(
        "getUpdates",
        http_timeout=wait_seconds + 20,
        offset=offset,
        timeout=wait_seconds,
        allowed_updates=["message", "callback_query"],
    )


def download_photo(file_id):
    info = _call("getFile", file_id=file_id)
    url = FILE_API.format(token=secret("TELEGRAM_BOT_TOKEN"), path=info["file_path"])
    resp = requests.get(url, timeout=60)
    resp.raise_for_status()
    return resp.content
