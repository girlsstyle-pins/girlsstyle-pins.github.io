"""Pin graphics: 1000×1500 px outfit collages from product photos, in the Girl's Style look.
Rendering is deterministic, so a draft's image can be rebuilt from its recipe when it is published."""
import io

import requests
from PIL import Image, ImageChops, ImageDraw, ImageFont

from .config import ASSETS_DIR

W, H = 1000, 1500
PAPER = (241, 242, 242)
INK = (0, 0, 0)
WHITE = (255, 255, 255)
MUTED = (184, 188, 194)
FONT_DIR = ASSETS_DIR / "fonts"
UA = {"User-Agent": "Mozilla/5.0 (compatible; GirlsStylePinPlanner/1.0)"}


def _font(name, size):
    return ImageFont.truetype(str(FONT_DIR / name), size)


def bold(size):
    return _font("Archivo-CondensedExtraBold.ttf", size)


def semi(size):
    return _font("Archivo-SemiBold.ttf", size)


def fetch_image(url):
    resp = requests.get(url, headers=UA, timeout=30)
    resp.raise_for_status()
    img = Image.open(io.BytesIO(resp.content))
    img.load()
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGB", img.size, WHITE)
        bg.paste(img, mask=img.split()[-1])
        img = bg
    else:
        img = img.convert("RGB")
    # trim plain white margins so the product fills its card
    diff = ImageChops.difference(img, Image.new("RGB", img.size, WHITE))
    diff = diff.convert("L").point(lambda v: 255 if v > 18 else 0)
    box = diff.getbbox()
    if box and (box[2] - box[0]) > 40 and (box[3] - box[1]) > 40:
        img = img.crop(box)
    return img


def _contain(img, w, h):
    scale = min(w / img.width, h / img.height)
    size = (max(1, int(img.width * scale)), max(1, int(img.height * scale)))
    return img.resize(size, Image.LANCZOS)


def draw_tag(draw, x, y, size=34):
    f = bold(size)
    pad_x, pad_y = int(size * 0.32), int(size * 0.18)
    left, right = "GIRL'S", "STYLE"
    lw = draw.textlength(left, font=f)
    rw = draw.textlength(right, font=f)
    asc, desc = f.getmetrics()
    th = asc + desc
    h = th + 2 * pad_y
    border = max(3, size // 9)
    total_w = lw + rw + 4 * pad_x
    draw.rectangle([x, y, x + total_w, y + h], fill=INK)
    draw.rectangle([x + lw + 2 * pad_x, y + border, x + total_w - border, y + h - border], fill=WHITE)
    draw.text((x + pad_x, y + pad_y), left, font=f, fill=WHITE)
    draw.text((x + lw + 3 * pad_x, y + pad_y), right, font=f, fill=INK)
    return h


def _wrap(draw, text, font, max_w):
    words, lines, line = text.split(), [], ""
    for word in words:
        test = f"{line} {word}".strip()
        if draw.textlength(test, font=font) <= max_w or not line:
            line = test
        else:
            lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines


def _fit_headline(draw, text, max_w, max_lines, sizes):
    for size in sizes:
        f = bold(size)
        lines = _wrap(draw, text, f, max_w)
        if len(lines) <= max_lines and all(draw.textlength(l, font=f) <= max_w for l in lines):
            return f, lines
    f = bold(sizes[-1])
    return f, _wrap(draw, text, f, max_w)[:max_lines]


def _slots(n, x0, y0, w, h, gap=20):
    if n == 1:
        return [(x0, y0, w, h)]
    if n == 2:
        cw = (w - gap) // 2
        return [(x0, y0, cw, h), (x0 + cw + gap, y0, cw, h)]
    if n == 3:
        lw = int(w * 0.58)
        rw = w - lw - gap
        rh = (h - gap) // 2
        return [(x0, y0, lw, h), (x0 + lw + gap, y0, rw, rh), (x0 + lw + gap, y0 + rh + gap, rw, rh)]
    cw, ch = (w - gap) // 2, (h - gap) // 2
    return [(x0, y0, cw, ch), (x0 + cw + gap, y0, cw, ch),
            (x0, y0 + ch + gap, cw, ch), (x0 + cw + gap, y0 + ch + gap, cw, ch)]


def collage(image_urls, headline, subline="Shop the look"):
    images = []
    for url in image_urls[:4]:
        try:
            images.append(fetch_image(url))
        except Exception:
            continue
    if not images:
        raise ValueError("Nie udało się pobrać żadnego zdjęcia produktu")

    canvas = Image.new("RGB", (W, H), PAPER)
    draw = ImageDraw.Draw(canvas)
    draw_tag(draw, 48, 40)

    area = (48, 118, W - 96, 960)
    for img, (x, y, w, h) in zip(images, _slots(len(images), *area)):
        draw.rectangle([x, y, x + w, y + h], fill=WHITE)
        pad = 26
        fitted = _contain(img, w - 2 * pad, h - 2 * pad)
        canvas.paste(fitted, (x + (w - fitted.width) // 2, y + (h - fitted.height) // 2))

    band_top = 1104
    draw.rectangle([0, band_top, W, H], fill=INK)
    font, lines = _fit_headline(draw, headline.upper(), W - 112, 3, [104, 96, 88, 80, 72, 64, 58])
    asc, desc = font.getmetrics()
    line_h = int((asc + desc) * 0.92)
    y = band_top + 44
    for line in lines:
        draw.text((56, y), line, font=font, fill=WHITE)
        y += line_h
    draw.text((56, H - 78), subline, font=semi(32), fill=MUTED)
    return _encode(canvas)


def typographic(headline, subline="Outfit ideas"):
    """Fallback pin without product photos (used for tests and when no feed is configured)."""
    canvas = Image.new("RGB", (W, H), PAPER)
    draw = ImageDraw.Draw(canvas)
    draw_tag(draw, 56, 56, size=44)
    font, lines = _fit_headline(draw, headline.upper(), W - 112, 6, [150, 136, 124, 112, 100, 90, 80])
    asc, desc = font.getmetrics()
    line_h = int((asc + desc) * 0.92)
    block_h = line_h * len(lines)
    y = (H - block_h) // 2 - 40
    for line in lines:
        draw.text((56, y), line, font=font, fill=INK)
        y += line_h
    draw.rectangle([56, y + 30, 56 + 160, y + 42], fill=INK)
    draw.text((56, y + 70), subline, font=semi(40), fill=(94, 99, 107))
    return _encode(canvas)


def _encode(img):
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=90, optimize=True, progressive=True)
    return buf.getvalue()


def render_draft(draft):
    if draft.get("kind") == "typographic":
        return typographic(draft["headline"], draft.get("subline", "Outfit ideas"))
    return collage(draft["image_urls"], draft["headline"])
