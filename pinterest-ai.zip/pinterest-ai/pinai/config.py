"""Settings: config.json (editable in GitHub) plus secrets from environment variables."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
ASSETS_DIR = ROOT / "assets"


def _load_config():
    with open(ROOT / "config.json", encoding="utf-8") as f:
        return json.load(f)


CONFIG = _load_config()


def cfg(key, default=None):
    return CONFIG.get(key, default)


def secret(name, required=True):
    value = os.environ.get(name, "").strip()
    if required and not value:
        raise RuntimeError(
            f"Brak sekretu {name}. Dodaj go w GitHub: Settings → Secrets and variables → Actions."
        )
    return value


def redirect_uri():
    return cfg("website").rstrip("/") + "/callback.html"
