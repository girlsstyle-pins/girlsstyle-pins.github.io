"""What the workflows run: connect, daily planning, hourly inbox/publishing, weekly review, test."""
import datetime as dt
import os
import re
import secrets as pysecrets
import time
import traceback
from zoneinfo import ZoneInfo

from . import ai, feed, render
from . import pinterest as pin
from . import state as st
from . import telegram as tg
from .config import cfg, secret

TZ = ZoneInfo(cfg("timezone", "Europe/Warsaw"))
CODE_RE = re.compile(r"^[A-Za-z0-9._~\-]{16,300}$")
HELP = (
    "<b>Komendy</b>\n"
    "/status – stan systemu\n"
    "/plan – przygotuj dodatkowe piny teraz\n"
    "/raport – raport i analiza teraz\n"
    "/tryb manual – zatwierdzone piny wrzucasz sam (domyślnie)\n"
    "/tryb sandbox – testowa publikacja przez API (widoczna tylko dla Ciebie)\n"
    "/tryb live – zatwierdzone piny publikuję automatycznie\n"
    "/pomoc – ta lista"
)


# --- small helpers --------------------------------------------------------------

def step_summary(text):
    path = os.environ.get("GITHUB_STEP_SUMMARY")
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(text + "\n\n")
    print(text)


def chat_id(state):
    return os.environ.get("TELEGRAM_CHAT_ID", "").strip() or state["telegram"].get("chat_id")


def notify(state, text, **kw):
    cid = chat_id(state)
    if cid:
        return tg.send_message(cid, text, **kw)
    step_summary(re.sub(r"<[^>]+>", "", text))


def get_client(state, env):
    """Pinterest client with fresh tokens, or None (with a message) when not connected."""
    try:
        return pin.Client.from_state(state, env)
    except pin.PinterestError as e:
        notify(state, f"⚠️ Pinterest ({env}): nie udało się odświeżyć dostępu ({tg.esc(e)}). "
                      "Uruchom „Połącz Pinterest” jeszcze raz.")
        return None


def local_now():
    return dt.datetime.now(TZ)


def fmt_time(ts):
    return dt.datetime.fromtimestamp(ts, TZ).strftime("%H:%M")


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# --- Telegram inbox ---------------------------------------------------------------

def process_inbox(state, wait_for_code_until=None):
    """Handle button presses and commands. If wait_for_code_until is set, keep listening until
    an authorization code arrives (returned) or the deadline passes."""
    while True:
        wait = 0
        if wait_for_code_until:
            wait = int(clamp(wait_for_code_until - time.time(), 0, 25))
        updates = tg.get_updates(state["telegram"].get("offset", 0), wait_seconds=wait)
        code = None
        for upd in updates:
            state["telegram"]["offset"] = upd["update_id"] + 1
            try:
                result = _handle_update(state, upd, expecting_code=bool(wait_for_code_until))
            except Exception as e:  # one bad update must not block the rest
                print("update error:", e)
                result = None
            if result:
                code = result
        if code:
            return code
        if not wait_for_code_until:
            if len(updates) < 100:  # Telegram returns at most 100 updates per call
                return None
            continue
        if time.time() >= wait_for_code_until:
            return None


def _handle_update(state, upd, expecting_code):
    if "callback_query" in upd:
        q = upd["callback_query"]
        cid = q.get("message", {}).get("chat", {}).get("id")
        if str(cid) != str(chat_id(state)):
            return None
        _handle_button(state, q)
        return None

    msg = upd.get("message") or {}
    cid = msg.get("chat", {}).get("id")
    text = (msg.get("text") or "").strip()
    if not cid or msg.get("chat", {}).get("type") != "private":
        return None
    if not chat_id(state):
        state["telegram"]["chat_id"] = cid
        tg.send_message(cid, "👋 Cześć! Jestem Twoim managerem Pinteresta Girl's Style. "
                             "Od teraz będę tu wysyłać propozycje pinów i raporty.\n\n" + HELP)
        if text.startswith("/start"):
            return None
    if str(cid) != str(chat_id(state)):
        return None

    if expecting_code and CODE_RE.match(text):
        return text
    command, _, arg = text.partition(" ")
    command = command.split("@")[0].lower()
    if command in ("/start", "/pomoc", "/help"):
        tg.send_message(cid, HELP)
    elif command == "/status":
        tg.send_message(cid, status_text(state))
    elif command == "/tryb":
        tg.send_message(cid, set_mode(state, arg.strip().lower()))
    elif command in ("/plan", "/raport"):
        pending = state.setdefault("pending_commands", [])
        if command not in pending:
            pending.append(command)
        tg.send_message(cid, "⏳ Przyjąłem. Zajmę się tym przy najbliższym sprawdzeniu (najpóźniej w ciągu godziny).")
    elif text.startswith("/"):
        tg.send_message(cid, "Nie znam tej komendy.\n\n" + HELP)
    return None


def _handle_button(state, q):
    action, _, did = (q.get("data") or "").partition(":")
    draft = st.find_draft(state, did)
    msg = q.get("message", {})
    if not draft:
        tg.answer_callback(q["id"], "Nie znam tego pina.")
        return
    if action == "x" or draft["status"] != "pending":
        tg.answer_callback(q["id"], f"Ten pin ma już status: {STATUS_PL.get(draft['status'], draft['status'])}")
        return
    if action == "r":
        draft["status"] = "rejected"
        draft["decided_at"] = st.now()
        tg.edit_buttons(msg["chat"]["id"], msg["message_id"], [[("❌ Odrzucony", f"x:{did}")]])
        tg.answer_callback(q["id"], "Odrzucony")
        return
    if action == "a":
        draft["status"] = "approved"
        draft["decided_at"] = st.now()
        if state["mode"] == "manual":
            send_manual_package(state, draft)
            label = "✅ Zatwierdzony – paczka do wrzucenia wysłana"
        else:
            label = f"✅ Zatwierdzony – publikacja ok. {fmt_time(max(draft['scheduled_ts'], st.now()))}"
        tg.edit_buttons(msg["chat"]["id"], msg["message_id"], [[(label, f"x:{did}")]])
        tg.answer_callback(q["id"], "Zatwierdzony")


STATUS_PL = {
    "pending": "czeka na decyzję", "approved": "zatwierdzony", "rejected": "odrzucony",
    "published": "opublikowany", "manual_sent": "wysłany do ręcznego wrzucenia",
    "expired": "wygasł", "failed": "błąd publikacji",
}


def set_mode(state, mode):
    if mode not in ("manual", "sandbox", "live"):
        return "Użyj: /tryb manual, /tryb sandbox albo /tryb live"
    if mode == "live" and not st.get_tokens(state, "production"):
        return "Najpierw połącz Pinterest (akcja „Połącz Pinterest” na GitHubie)."
    expected = cfg("pinterest_username", "").lower()
    connected = state.get("account", {}).get("username", "").lower()
    if mode == "live" and expected and connected != expected:
        return (f"⛔ Połączone jest konto @{connected}, a nie @{cfg('pinterest_username')}. "
                "Nie włączę publikacji, żeby nic nie trafiło na złe konto. Połącz właściwe konto.")
    if mode == "sandbox" and not st.get_tokens(state, "sandbox"):
        return "Najpierw połącz Pinterest w trybie sandbox (akcja „Połącz Pinterest”, pole env: sandbox)."
    state["mode"] = mode
    extra = {
        "manual": "Po kliknięciu ✅ dostaniesz grafikę i teksty do wrzucenia ręcznie.",
        "sandbox": "Zatwierdzone piny trafią do sandboxa – zobaczysz je tylko Ty. Do nagrania wideo dla Pinteresta.",
        "live": "Zatwierdzone piny opublikuję sam o zaplanowanej godzinie.",
    }[mode]
    return f"✅ Tryb: <b>{mode}</b>. {extra}"


def status_text(state):
    acc = state.get("account", {})
    pending = sum(1 for d in state["drafts"] if d["status"] == "pending")
    approved = sum(1 for d in state["drafts"] if d["status"] == "approved")
    week_ago = st.now() - 7 * 86400
    published = sum(1 for d in state["drafts"] if d["status"] in ("published", "manual_sent")
                    and d.get("decided_at", 0) > week_ago)
    lines = [
        "<b>Status</b>",
        f"Tryb: {state['mode']}",
        f"Pinterest: {'@' + acc['username'] + ' (' + acc.get('type', '?') + ')' if acc.get('username') else 'niepołączony'}",
        f"Sandbox: {'połączony' if st.get_tokens(state, 'sandbox') else 'niepołączony'}",
        f"Czeka na decyzję: {pending}, zatwierdzone do publikacji: {approved}",
        f"Wrzucone w ostatnim tygodniu: {published}",
        f"Piny dziennie (zalecenie AI): {state.get('recommended_pins_per_day', cfg('max_pins_per_day'))}",
    ]
    return "\n".join(lines)


# --- connect ----------------------------------------------------------------------

def connect(env="production", code=""):
    state = st.load()
    process_inbox(state)
    code = (code or "").strip()
    if not code:
        url = pin.authorize_url(pysecrets.token_urlsafe(12))
        text = (
            f"🔗 <b>Połączenie z Pinterestem ({env})</b>\n\n"
            "1. Otwórz link poniżej (najlepiej będąc zalogowanym na konto Girl's Style).\n"
            "2. Kliknij <b>Give access</b>.\n"
            "3. Skopiuj kod ze strony, na którą trafisz, i wyślij go tutaj jako wiadomość.\n"
            "Czekam 10 minut.\n\n"
            f'👉 <a href="{tg.esc(url)}">Otwórz Pinterest i daj dostęp</a>'
        )
        if chat_id(state):
            notify(state, text)
        else:
            step_summary("Wyślij /start do swojego bota na Telegramie, potem otwórz link i wyślij botowi kod:\n\n" + url)
        st.save(state)
        code = process_inbox(state, wait_for_code_until=time.time() + 600)
        if not code:
            st.save(state)
            notify(state, "⌛ Nie dostałem kodu w ciągu 10 minut. Uruchom „Połącz Pinterest” jeszcze raz.")
            raise SystemExit(1)

    bundle = pin.exchange_code(env, code)
    st.set_tokens(state, env, bundle)
    client = pin.Client(env, bundle["access_token"])
    info = client.user_account()
    username = info.get("username", "?")
    acc_type = info.get("account_type", "?")
    if env == "production":
        state["account"] = {"username": username, "type": acc_type, "connected_at": st.now()}
    st.save(state)

    lines = [f"✅ Połączono ({env}) z kontem <b>@{tg.esc(username)}</b> ({tg.esc(acc_type)})."]
    expected = cfg("pinterest_username", "").lower()
    if expected and username.lower() != expected:
        lines.append(f"⚠️ To nie jest @{cfg('pinterest_username')}. Jeśli to konto osobiste, nadaj kontu "
                     "Girl's Style osobny e-mail, zaloguj się na nie i połącz jeszcze raz.")
    elif acc_type != "BUSINESS":
        lines.append("⚠️ To nie jest konto firmowe – publikacja przez API może nie działać.")
    if env == "production":
        try:
            boards = client.boards()
            lines.append(f"Tablice: {len(boards)} – " + ", ".join(tg.esc(b['name']) for b in boards[:12]))
        except pin.PinterestError as e:
            lines.append(f"Nie udało się pobrać tablic: {tg.esc(e)}")
    notify(state, "\n".join(lines))


# --- daily planning ---------------------------------------------------------------

def _analytics_context(client, state):
    ctx = {}
    if not client:
        return {"note": "Pinterest not connected yet – no analytics available."}
    try:
        last = client.account_summary(30)
        prev = client.account_summary(30, end_offset=31)
        ctx["account_last_30d"] = last
        ctx["account_previous_30d"] = prev
    except pin.PinterestError as e:
        ctx["account_error"] = str(e)
    for sort in ("IMPRESSION", "OUTBOUND_CLICK"):
        try:
            ctx[f"top_pins_30d_by_{sort.lower()}"] = client.top_pins(30, sort, limit=6)
        except pin.PinterestError as e:
            ctx[f"top_pins_error_{sort.lower()}"] = str(e)
    ours = []
    cutoff = st.now() - 60 * 86400
    for d in reversed(state["drafts"]):
        if d.get("pin_id") and d.get("decided_at", 0) > cutoff and len(ours) < 15:
            try:
                ours.append({"title": d["title"], "keyword": d["target_keyword"],
                             "published": fmt_date(d.get("published_at")),
                             "metrics": client.pin_metrics(d["pin_id"], 30)})
            except pin.PinterestError:
                pass
    ctx["our_published_pins_last_60d"] = ours
    return ctx


def fmt_date(ts):
    return dt.datetime.fromtimestamp(ts, TZ).strftime("%Y-%m-%d") if ts else None


def _trends(client):
    out, errors = {}, []
    if not client:
        return out, ["not connected"]
    for i, region in enumerate(cfg("trend_regions", [])):
        types = ["growing", "seasonal"] if i == 0 else ["growing"]
        for ttype in types:
            try:
                out[f"{region}/{ttype}"] = client.trending_keywords(region, ttype, cfg("trend_interest"), limit=15)
            except pin.PinterestError as e:
                errors.append(f"{region}/{ttype}: {e}")
    return out, errors


def _recent_drafts(state, n=30):
    return [
        {"date": fmt_date(d["created_at"]), "concept": d["concept"], "keyword": d["target_keyword"],
         "board": d.get("board_name"), "status": d["status"]}
        for d in state["drafts"][-n:]
    ]


def _slot_times(requested, n, now=None):
    """Turn the AI's 'HH:MM' wishes into real publish times inside the allowed hours,
    at least 2 hours apart; anything that does not fit today moves to tomorrow morning."""
    lo, hi = cfg("publish_hours", [9, 22])
    now = now or local_now()
    soon = now + dt.timedelta(minutes=30)
    soon = (soon + dt.timedelta(minutes=(15 - soon.minute % 15) % 15)).replace(second=0, microsecond=0)
    cursor = max(soon, now.replace(hour=lo, minute=0, second=0, microsecond=0))
    wishes = []
    for raw in list(requested)[:n]:
        try:
            h, m = (int(x) for x in raw.strip().split(":")[:2])
            wishes.append((clamp(h, 0, 23), clamp(m, 0, 59)))
        except (ValueError, AttributeError):
            pass
    wishes.sort()
    wishes += [None] * (n - len(wishes))
    out = []
    for hm in wishes:
        wish = cursor.replace(hour=hm[0], minute=hm[1], second=0, microsecond=0) if hm else None
        t = wish if wish is not None and wish >= cursor else cursor
        if t > t.replace(hour=hi, minute=0, second=0, microsecond=0):
            t = (t + dt.timedelta(days=1)).replace(hour=lo, minute=0, second=0, microsecond=0)
        out.append(t)
        cursor = t + dt.timedelta(hours=2)
    return [int(t.timestamp()) for t in out]


def _match_board(boards, name):
    if not boards:
        return None, name or ""
    for b in boards:
        if b["name"].strip().lower() == (name or "").strip().lower():
            return b["id"], b["name"]
    for b in boards:
        if (name or "").strip().lower() in b["name"].lower():
            return b["id"], b["name"]
    best = max(boards, key=lambda b: b.get("pin_count", 0))
    return best["id"], best["name"]


def _final_description(desc, with_disclosure):
    desc = desc.strip()
    if not with_disclosure:
        return desc[:500]
    disclosure = cfg("disclosure", "#affiliate")
    room = 500 - len(disclosure) - 2
    if len(desc) > room:
        desc = desc[:room].rsplit(" ", 1)[0].rstrip(",.;") + "…"
    return f"{desc}\n\n{disclosure}"


def daily(extra=False, test=False):
    state = st.load()
    process_inbox(state)
    if not chat_id(state):
        step_summary("Bot nie zna jeszcze Twojego czatu. Otwórz bota na Telegramie, kliknij Start i uruchom akcję ponownie.")
        st.save(state)
        raise SystemExit(1)
    client = get_client(state, "production")
    boards = []
    if client:
        try:
            boards = [{"id": b["id"], "name": b["name"], "pin_count": b.get("pin_count", 0)} for b in client.boards()]
        except pin.PinterestError as e:
            notify(state, f"⚠️ Nie pobrałem tablic: {tg.esc(e)}")

    products, feed_errors = feed.load_products()
    for err in feed_errors:
        notify(state, f"⚠️ Feed produktów: {tg.esc(err)}", silent=True)

    recommended = state.get("recommended_pins_per_day", cfg("max_pins_per_day"))
    max_pins = 2 if test else clamp(recommended, cfg("min_pins_per_day"), cfg("max_pins_per_day"))
    if extra:
        max_pins = clamp(max_pins, 1, 2)
    trends, trend_errors = _trends(client)
    context = {
        "max_pins": max_pins,
        "recommended_pins_per_day": recommended,
        "extra_request_from_owner": extra,
        "boards": [{"name": b["name"], "pins": b["pin_count"]} for b in boards] or "unknown (not connected) – suggest a sensible board name",
        "strategy_notes": st.load_strategy(),
        "analytics": _analytics_context(client, state),
        "pinterest_trends": trends,
        "trend_errors": trend_errors[:4],
        "recent_drafts": _recent_drafts(state),
        "product_feed": feed.vocabulary_sample(products) if products else "No product feed connected – plan inspiration Pins that link to our website.",
    }
    plan = ai.plan_day(context)
    pins_planned = plan.get("pins", [])
    n = clamp(int(plan.get("pins_today") or len(pins_planned)), 1, max_pins)
    pins_planned = pins_planned[:n]
    if not pins_planned:
        notify(state, "🤷 AI nie zaplanowało dziś żadnego pina.")
        st.save(state)
        return

    concepts, used = [], set()
    for i, p in enumerate(pins_planned):
        roles = []
        if products:
            for q in p.get("item_queries", [])[:4]:
                cands = feed.search(products, q, limit=6, exclude=used)
                if cands:
                    roles.append({"query": q, "candidates": [
                        {k: c[k] for k in ("id", "name", "brand", "merchant", "colour", "price", "currency")}
                        for c in cands]})
                    used.update(c["id"] for c in cands[:1])
        concepts.append({"index": i, "concept": p["concept"], "target_keyword": p["target_keyword"],
                         "no_products": not roles, "roles": roles})
    written = {w["index"]: w for w in ai.write_pins(concepts).get("pins", []) if isinstance(w.get("index"), int)}
    by_id = {c["id"]: c for c in products}
    times = _slot_times([p.get("time", "") for p in pins_planned], len(pins_planned))

    header = f"📅 <b>{'Dodatkowe piny' if extra else 'Plan na dziś'}{' (TEST)' if test else ''}</b>: {len(pins_planned)}\n{tg.esc(plan.get('analysis_pl', ''))}"
    if not client:
        header += "\n\nℹ️ Pinterest nie jest jeszcze połączony – planuję bez statystyk i trendów."
    notify(state, header)

    sent = 0
    for i, p in enumerate(pins_planned):
        w = written.get(i)
        if not w:
            continue
        allowed = {c["id"] for r in concepts[i]["roles"] for c in r["candidates"]}
        chosen = [by_id[pid] for pid in w.get("product_ids", []) if pid in allowed and pid in by_id][:4]
        hero = by_id.get(w.get("hero_product_id")) if w.get("hero_product_id") in allowed else None
        if chosen and (not hero or hero not in chosen):
            hero = chosen[0]
        draft = {
            "id": st.new_draft_id(state),
            "created_at": st.now(),
            "status": "pending",
            "test": test,
            "concept": p["concept"],
            "target_keyword": p["target_keyword"],
            "title": w["title"].strip()[:100],
            "alt_text": w["alt_text"].strip()[:500],
            "headline": w["headline"].strip()[:40],
            "scheduled_ts": times[i],
        }
        draft["board_id"], draft["board_name"] = _match_board(boards, p.get("board"))
        if chosen:
            ordered = [hero] + [c for c in chosen if c is not hero]
            draft.update({
                "kind": "collage",
                "image_urls": [c["image"] for c in ordered],
                "link": hero["link"],
                "hero": {"name": hero["name"], "merchant": hero["merchant"]},
                "description": _final_description(w["description"], True),
            })
        else:
            if concepts[i]["roles"]:
                continue  # products were available but the AI found no sensible outfit
            draft.update({
                "kind": "typographic",
                "subline": "Outfit ideas",
                "link": cfg("website"),
                "description": _final_description(w["description"], False),
            })
        try:
            image = render.render_draft(draft)
        except Exception as e:
            notify(state, f"⚠️ Nie zrobiłem grafiki dla „{tg.esc(draft['title'])}”: {tg.esc(e)}", silent=True)
            continue
        caption = _caption(draft, sent + 1, len(pins_planned), state["mode"])
        result = tg.send_photo(chat_id(state), image, caption,
                               buttons=[[("✅ Publikuj", f"a:{draft['id']}"), ("❌ Odrzuć", f"r:{draft['id']}")]])
        draft["tg_message_id"] = result.get("message_id")
        if result.get("photo"):
            draft["tg_file_id"] = result["photo"][-1]["file_id"]
        state["drafts"].append(draft)
        sent += 1
        st.save(state)

    if sent < len(pins_planned):
        notify(state, f"ℹ️ Wysłałem {sent} z {len(pins_planned)} zaplanowanych – dla pozostałych nie udało się "
                      "dobrać produktów albo grafiki.", silent=True)
    if not extra and not test:
        state["last_daily_run"] = st.now()
    st.save(state)
    step_summary(f"Wysłane propozycje pinów: {sent}")


def _caption(d, n, total, mode):
    desc = d["description"].split("\n\n" + cfg("disclosure", "#affiliate"))[0]
    when = fmt_time(d["scheduled_ts"])
    lines = [f"<b>{n}/{total} · {when}</b> · {tg.esc(d['title'])}", "", tg.esc(desc[:380])]
    lines.append("")
    lines.append(f"📋 Tablica: {tg.esc(d.get('board_name') or '—')}")
    if d.get("hero"):
        lines.append(f"🛍 {tg.esc(d['hero']['merchant'])}: {tg.esc(d['hero']['name'][:80])}")
    lines.append(f"🔑 {tg.esc(d['target_keyword'])}")
    lines.append("")
    if mode == "manual":
        lines.append("✅ = dostaniesz grafikę i teksty do wrzucenia.")
    else:
        lines.append(f"✅ = opublikuję o {when}.")
    lines.append("Kliknięcia sprawdzam co godzinę.")
    return "\n".join(lines)


# --- publishing -------------------------------------------------------------------

def _image_for(draft):
    try:
        return render.render_draft(draft)
    except Exception:
        if draft.get("tg_file_id"):
            return tg.download_photo(draft["tg_file_id"])
        raise


def send_manual_package(state, draft):
    image = _image_for(draft)
    tg.send_document(chat_id(state), image, f"pin-{draft['id']}.jpg",
                     caption=f"📌 Do wrzucenia: <b>{tg.esc(draft['title'])}</b>")
    text = (
        "<b>Tytuł</b>\n<code>" + tg.esc(draft["title"]) + "</code>\n\n"
        "<b>Opis</b>\n<pre>" + tg.esc(draft["description"]) + "</pre>\n\n"
        "<b>Link</b>\n<code>" + tg.esc(draft["link"]) + "</code>\n\n"
        "<b>Tekst alternatywny</b>\n<code>" + tg.esc(draft["alt_text"]) + "</code>\n\n"
        f"📋 Tablica: {tg.esc(draft.get('board_name') or '—')} · najlepiej ok. {fmt_time(max(draft['scheduled_ts'], st.now()))}\n"
        "Stuknij tekst, żeby go skopiować."
    )
    tg.send_message(chat_id(state), text)
    draft["status"] = "manual_sent"
    draft["published_at"] = st.now()


def _sandbox_board(client):
    boards = client.boards()
    if boards:
        return boards[0]["id"], boards[0]["name"]
    b = client.create_board("Outfit Ideas", "Women's streetwear outfit ideas")
    return b["id"], b["name"]


def publish_due(state):
    due = [d for d in state["drafts"] if d["status"] == "approved" and d["scheduled_ts"] <= st.now()]
    if not due:
        return
    mode = state["mode"]
    if mode == "manual":
        for d in due:
            send_manual_package(state, d)
        return
    env = "sandbox" if mode == "sandbox" else "production"
    client = get_client(state, env)
    if not client:
        notify(state, f"⚠️ Nie mogę publikować: Pinterest ({env}) nie jest połączony. Przełączam na /tryb manual.")
        state["mode"] = "manual"
        return
    for d in due:
        try:
            if env == "sandbox":
                board_id, board_name = _sandbox_board(client)
            else:
                board_id, board_name = d.get("board_id"), d.get("board_name")
                if not board_id:
                    boards = client.boards()
                    board_id, board_name = _match_board(
                        [{"id": b["id"], "name": b["name"], "pin_count": b.get("pin_count", 0)} for b in boards],
                        d.get("board_name"))
            image = _image_for(d)
            result = client.create_pin(board_id, d["title"], d["description"], d["link"], d["alt_text"], image)
            d["status"] = "published"
            d["pin_id"] = result.get("id")
            d["published_at"] = st.now()
            url = f"https://www.pinterest.com/pin/{d['pin_id']}/" if env == "production" else "(sandbox – widoczny tylko dla Ciebie)"
            notify(state, f"📌 Opublikowano na „{tg.esc(board_name)}”: <b>{tg.esc(d['title'])}</b>\n{url}", silent=True)
        except Exception as e:
            d["attempts"] = d.get("attempts", 0) + 1
            if d["attempts"] >= 3:
                d["status"] = "failed"
            notify(state, f"⚠️ Publikacja „{tg.esc(d['title'])}” nie wyszła ({d['attempts']}/3): {tg.esc(e)}")
        st.save(state)


def expire_old(state):
    limit = st.now() - cfg("draft_expiry_days", 3) * 86400
    for d in state["drafts"]:
        if d["status"] == "pending" and d["created_at"] < limit:
            d["status"] = "expired"
            if d.get("tg_message_id") and chat_id(state):
                tg.edit_buttons(chat_id(state), d["tg_message_id"], [[("⌛ Wygasł", f"x:{d['id']}")]])


# --- hourly -----------------------------------------------------------------------

def poll():
    state = st.load()
    process_inbox(state)
    expire_old(state)
    publish_due(state)
    st.save(state)
    pending = state.pop("pending_commands", [])
    st.save(state)
    if "/plan" in pending:
        daily(extra=True)
    if "/raport" in pending:
        weekly()


# --- weekly -----------------------------------------------------------------------

def weekly():
    state = st.load()
    process_inbox(state)
    client = get_client(state, "production")
    ctx = {"mode": state["mode"], "previous_strategy_notes": st.load_strategy(),
           "current_recommended_pins_per_day": state.get("recommended_pins_per_day", cfg("max_pins_per_day"))}
    if client:
        try:
            ctx["last_7d"] = client.account_summary(7)
            ctx["previous_7d"] = client.account_summary(7, end_offset=8)
            ctx["last_30d"] = client.account_summary(30)
            ctx["previous_30d"] = client.account_summary(30, end_offset=31)
        except pin.PinterestError as e:
            ctx["analytics_error"] = str(e)
        ctx.update(_analytics_context(client, state))
    else:
        ctx["note"] = "Pinterest not connected – only internal draft statistics available."
    week_ago = st.now() - 7 * 86400
    recent = [d for d in state["drafts"] if d["created_at"] > week_ago]
    ctx["drafts_last_7d"] = {s: sum(1 for d in recent if d["status"] == s) for s in STATUS_PL}
    ctx["rejected_concepts_last_7d"] = [d["concept"] for d in recent if d["status"] == "rejected"][:10]
    res = ai.weekly_review(ctx)
    st.save_strategy(res["strategy_markdown"])
    state["recommended_pins_per_day"] = clamp(int(res.get("recommended_pins_per_day") or cfg("max_pins_per_day")),
                                              cfg("min_pins_per_day"), cfg("max_pins_per_day"))
    state["last_weekly_run"] = st.now()
    st.save(state)
    notify(state, "📊 <b>Raport tygodniowy</b>\n\n" + tg.esc(res["report_pl"]))


# --- test -------------------------------------------------------------------------

def test():
    state = st.load()
    process_inbox(state)
    if not chat_id(state):
        step_summary("❗ Bot nie zna Twojego czatu. Otwórz bota na Telegramie, kliknij Start i uruchom „Test” jeszcze raz.")
        st.save(state)
        raise SystemExit(1)
    lines = ["🔧 <b>Test systemu</b>", "Telegram: ✅"]
    try:
        ai.test_ping()
        lines.append("Claude (AI): ✅")
    except Exception as e:
        lines.append(f"Claude (AI): ❌ {tg.esc(e)}")
    client = get_client(state, "production")
    if client:
        try:
            info = client.user_account()
            lines.append(f"Pinterest: ✅ @{tg.esc(info.get('username'))} ({tg.esc(info.get('account_type'))})")
        except Exception as e:
            lines.append(f"Pinterest: ❌ {tg.esc(e)}")
    else:
        lines.append("Pinterest: niepołączony (uruchom „Połącz Pinterest”, gdy dostaniesz dostęp Trial)")
    if secret("AWIN_FEED_URL", required=False):
        products, errors = feed.load_products()
        lines.append(f"Feed produktów: {'✅' if products else '❌'} {len(products)} produktów" +
                     (f" ({tg.esc(errors[0])})" if errors else ""))
    else:
        lines.append("Feed produktów: brak (dodaj sekret AWIN_FEED_URL po akceptacji w programach)")
    lines.append(f"Tryb publikacji: {state['mode']}")
    notify(state, "\n".join(lines))
    st.save(state)
    daily(test=True)


def run(job, **kwargs):
    jobs = {"connect": connect, "daily": daily, "poll": poll, "weekly": weekly, "test": test}
    try:
        jobs[job](**kwargs)
    except SystemExit:
        raise
    except Exception as e:
        traceback.print_exc()
        try:
            notify(st.load(), f"❗ Błąd w zadaniu „{job}”: {tg.esc(e)}")
        except Exception:
            pass
        raise SystemExit(1)
