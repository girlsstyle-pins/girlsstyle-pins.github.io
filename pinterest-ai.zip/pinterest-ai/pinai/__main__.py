"""Entry point used by the GitHub Actions workflows: python -m pinai <job>."""
import os
import sys

from .jobs import run


def main():
    job = sys.argv[1] if len(sys.argv) > 1 else ""
    if job in ("daily", "poll", "weekly") and not os.environ.get("TELEGRAM_BOT_TOKEN"):
        print("System nie jest jeszcze skonfigurowany (brak sekretu TELEGRAM_BOT_TOKEN) – pomijam.")
        return
    if job == "connect":
        run("connect", env=os.environ.get("CONNECT_ENV", "production") or "production",
            code=os.environ.get("CONNECT_CODE", ""))
    elif job in ("daily", "poll", "weekly", "test"):
        run(job)
    else:
        print("Użycie: python -m pinai connect|daily|poll|weekly|test")
        sys.exit(2)


if __name__ == "__main__":
    main()
