"""Product data from Awin feeds (Toolbox → Create-a-Feed). Each product carries its own tracked
affiliate link (aw_deep_link), so no links have to be built by hand."""
import csv
import gzip
import io
import random
import re
import zipfile

import requests

from .config import secret

IMAGE_COLUMNS = ["large_image", "merchant_image_url", "image_url", "alternate_image", "aw_image_url"]
MEN_ONLY = re.compile(r"\b(men|mens|men's|herren|homme|male|boys?)\b", re.I)
WOMEN = re.compile(r"\b(women|womens|women's|damen|femme|female|ladies|girls?|wmns)\b", re.I)


def _decompress(raw):
    if raw[:2] == b"\x1f\x8b":
        return gzip.decompress(raw)
    if raw[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            name = next(n for n in z.namelist() if not n.endswith("/"))
            return z.read(name)
    return raw


def _rows(text):
    first = text.split("\n", 1)[0]
    delimiter = max([",", ";", "\t", "|"], key=first.count)
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    for row in reader:
        yield {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}


def _product(row, index):
    link = row.get("aw_deep_link") or row.get("deep_link")
    name = row.get("product_name") or row.get("title")
    image = next((row[c] for c in IMAGE_COLUMNS if row.get(c, "").startswith("http")), "")
    if not (link and name and image):
        return None
    stock = row.get("in_stock", "1")
    if stock in ("0", "", "false", "no"):
        return None
    gender = " ".join([row.get("suitable_for", ""), row.get("gender", ""), row.get("custom_1", "")])
    if MEN_ONLY.search(gender) and not WOMEN.search(gender):
        return None
    return {
        "id": f"p{index}",
        "name": name[:140],
        "brand": row.get("brand_name", "")[:40],
        "merchant": row.get("merchant_name", "")[:40],
        "category": (row.get("merchant_category") or row.get("category_name") or "")[:80],
        "colour": row.get("colour", "")[:30],
        "price": row.get("search_price") or row.get("store_price") or "",
        "currency": row.get("currency", ""),
        "image": image,
        "link": link,
        "women": bool(WOMEN.search(" ".join([gender, name, row.get("merchant_category", "")]))),
    }


def load_products(limit=150000):
    urls = secret("AWIN_FEED_URL", required=False).split()
    products = []
    errors = []
    for url in urls:
        try:
            resp = requests.get(url, timeout=180)
            resp.raise_for_status()
            text = _decompress(resp.content).decode("utf-8-sig", errors="replace")
            for row in _rows(text):
                p = _product(row, len(products))
                if p:
                    products.append(p)
                if len(products) >= limit:
                    break
        except Exception as e:  # one broken feed should not stop the others
            errors.append(f"{url[:60]}…: {e}")
    return products, errors


def _tokens(text):
    return [t for t in re.split(r"[^\wäöüßéèàç]+", text.lower()) if len(t) > 1]


def search(products, query, limit=8, exclude=()):
    q = _tokens(query)
    if not q:
        return []
    scored = []
    for p in products:
        if p["id"] in exclude:
            continue
        name = p["name"].lower()
        cat = p["category"].lower()
        colour = p["colour"].lower()
        score = 0.0
        for t in q:
            if t in name:
                score += 3
            if t in cat:
                score += 2
            if t in colour:
                score += 1
        if score == 0:
            continue
        if all(t in name or t in cat or t in colour for t in q):
            score += 4
        if p["women"]:
            score += 1.5
        scored.append((score + random.random() * 0.5, p))
    scored.sort(key=lambda x: -x[0])
    seen, out = set(), []
    for _, p in scored:
        key = p["name"].lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
        if len(out) >= limit:
            break
    return out


def vocabulary_sample(products, n=60):
    """A random sample of product names so the AI writes search terms in the feed's own language."""
    sample = random.sample(products, min(n, len(products)))
    cats = {}
    for p in products:
        if p["category"]:
            cats[p["category"]] = cats.get(p["category"], 0) + 1
    top_cats = [c for c, _ in sorted(cats.items(), key=lambda x: -x[1])[:40]]
    merchants = sorted({p["merchant"] for p in products if p["merchant"]})
    return {
        "product_names": [p["name"] for p in sample],
        "categories": top_cats,
        "merchants": merchants[:20],
        "total_products": len(products),
    }
