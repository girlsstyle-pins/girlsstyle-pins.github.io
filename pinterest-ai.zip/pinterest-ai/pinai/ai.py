"""The AI manager: Claude plans the day, writes Pin copy and reviews performance every week."""
import datetime as dt
import json

import requests

from .config import cfg, secret

API_URL = "https://api.anthropic.com/v1/messages"


def _obj(properties, required=None):
    return {
        "type": "object",
        "properties": properties,
        "required": required or list(properties),
        "additionalProperties": False,
    }


S = {"type": "string"}
I = {"type": "integer"}


def ask_json(system, user, schema, max_tokens=8000):
    payload = {
        "model": cfg("ai_model", "claude-sonnet-5-5"),
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
        "output_config": {"format": {"type": "json_schema", "schema": schema}},
    }
    headers = {
        "x-api-key": secret("ANTHROPIC_API_KEY"),
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    for attempt in range(2):
        resp = requests.post(API_URL, headers=headers, json=payload, timeout=300)
        if resp.status_code >= 400:
            raise RuntimeError(f"Claude API {resp.status_code}: {resp.text[:300]}")
        body = resp.json()
        if body.get("stop_reason") == "max_tokens" and attempt == 0:
            payload["max_tokens"] = max_tokens * 2
            continue
        text = "".join(b.get("text", "") for b in body.get("content", []) if b.get("type") == "text")
        return json.loads(text)
    raise RuntimeError("Claude: odpowiedź za długa")


def _role():
    return (
        f"You are the full-time Pinterest manager for the account \"{cfg('brand')}\" "
        f"(@{cfg('pinterest_username')}), niche: {cfg('niche')}. You think like an experienced "
        "Pinterest marketer: Pinterest is a visual search engine, so titles and descriptions must "
        "contain the exact phrases people search for; consistency beats volume; seasonal content "
        "must go out 4–8 weeks before the season peaks; fresh Pins (new images) work better than "
        "repins. The goal is outbound clicks on affiliate product links, not vanity reach.\n"
        "Hard rules: never exceed the daily limit you are given; never make claims about prices, "
        "discounts or stock; no clickbait; no more than 3 hashtags; write Pin text in "
        f"{cfg('pin_language', 'English')}; only use boards from the list you are given; avoid "
        "repeating concepts from recent drafts. The affiliate disclosure is added automatically, "
        "do not write it yourself."
    )


def plan_day(context):
    today = dt.date.today()
    schema = _obj({
        "analysis_pl": S,
        "pins_today": I,
        "pins": {"type": "array", "items": _obj({
            "concept": S,
            "target_keyword": S,
            "board": S,
            "time": S,
            "item_queries": {"type": "array", "items": S},
        })},
    })
    user = (
        f"Today is {today:%A, %d %B %Y}. Plan today's Pins.\n\n"
        f"Allowed number of Pins today: {cfg('min_pins_per_day')}–{context['max_pins']}. "
        f"Allowed publish times (local time {cfg('timezone')}): between "
        f"{cfg('publish_hours')[0]}:00 and {cfg('publish_hours')[1]}:00, at least 2 hours apart.\n\n"
        "Each Pin is an outfit collage made from 2–4 real products from our affiliate feed, plus a "
        "short headline printed on the image. For each Pin give 2–4 item_queries: short product "
        "search terms (1–3 words each) in the same language and vocabulary as the product names in "
        "the feed sample (for example a German feed needs German or brand terms), together forming "
        "one coherent outfit. target_keyword is the main Pinterest search phrase (prefer rising "
        "trends that fit the niche).\n"
        "analysis_pl: 2–3 short sentences in Polish for the owner explaining today's choices "
        "(what you push and why, how many Pins and why).\n\n"
        f"CONTEXT (JSON):\n{json.dumps(context, ensure_ascii=False, indent=1)}"
    )
    return ask_json(_role(), user, schema, max_tokens=6000)


def write_pins(concepts):
    schema = _obj({
        "pins": {"type": "array", "items": _obj({
            "index": I,
            "product_ids": {"type": "array", "items": S},
            "hero_product_id": S,
            "title": S,
            "description": S,
            "alt_text": S,
            "headline": S,
        })},
    })
    user = (
        "For each planned Pin below, choose 2–4 products from its candidates that together make a "
        "coherent, wearable outfit (one item per role, matching colours and style; skip anything "
        "that is not women's clothing, shoes or accessories). Then write:\n"
        "- title: max 90 characters, starts with the target keyword or a close variant, natural.\n"
        "- description: 250–450 characters, helpful styling tip in 2–3 sentences, includes the "
        "target keyword and 2–3 related search phrases naturally, max 3 hashtags at the end.\n"
        "- alt_text: max 300 characters describing what is in the image for visually impaired users.\n"
        "- headline: 2–6 words printed on the image, max 32 characters, punchy, no hashtags.\n"
        "- hero_product_id: the product the Pin links to (the most clickable, central piece).\n"
        "If no candidate set can make a sensible outfit, return product_ids as an empty list.\n\n"
        f"PLANNED PINS (JSON):\n{json.dumps(concepts, ensure_ascii=False, indent=1)}"
    )
    return ask_json(_role(), user, schema, max_tokens=8000)


def weekly_review(context):
    schema = _obj({
        "report_pl": S,
        "strategy_markdown": S,
        "recommended_pins_per_day": I,
    })
    user = (
        "Do the weekly review of the account, like a manager reporting to the owner.\n"
        "report_pl: a Telegram message in Polish (max 1500 characters, plain text with short "
        "lines, no markdown tables): key numbers vs the previous period, what worked and what did "
        "not (be specific: topics, formats, boards, times), outbound clicks as the main KPI, how "
        "many Pins per day you recommend from now on and why, and up to 3 concrete actions for "
        "the owner (e.g. a board to create). Be honest when data is too thin to conclude.\n"
        "strategy_markdown: your updated working notes in English for planning the next weeks: "
        "posting frequency, topics/keywords to push or drop, best times, board usage, seasonal "
        "calendar for the next 8 weeks. Max 2500 characters. Keep what is still valid from the "
        "previous notes.\n"
        f"recommended_pins_per_day: integer between {cfg('min_pins_per_day')} and "
        f"{cfg('max_pins_per_day')}.\n\n"
        f"CONTEXT (JSON):\n{json.dumps(context, ensure_ascii=False, indent=1)}"
    )
    return ask_json(_role(), user, schema, max_tokens=6000)


def test_ping():
    schema = _obj({"reply": S})
    return ask_json("Reply briefly.", "Say 'ok' in Polish in one word.", schema, max_tokens=200)
