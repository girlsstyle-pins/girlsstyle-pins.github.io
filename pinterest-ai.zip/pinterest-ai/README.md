# Girl's Style Pin Planner

AI-manager konta Girl's Style na Pintereście. Działa sam na GitHubie, a Ty tylko zatwierdzasz piny na Telegramie.

**Co robi**
- Codziennie rano analizuje statystyki konta i trendy Pinteresta, decyduje, ile i jakich pinów wrzucić, i przysyła propozycje na Telegram.
- Każdy pin to kolaż stylizacji ze zdjęć produktów z Twoich programów afiliacyjnych (Awin) z linkiem afiliacyjnym, tytułem i opisem pod SEO.
- Co godzinę sprawdza Twoje decyzje (✅ / ❌) i publikuje zatwierdzone piny o zaplanowanej godzinie.
- W każdy poniedziałek wysyła raport: co działa, co nie, ile pinów dziennie dalej i co zmienić.
- Nic nie trafia na Pinterest bez Twojego ✅ przy konkretnym pinie (tego wymagają zasady Pinteresta).

## 1. Wgranie (5 minut)

1. Rozpakuj `pinterest-ai.zip`.
2. Na GitHubie otwórz prywatne repozytorium `pinterest-ai` → **Add file → Upload files**.
3. Wejdź do rozpakowanego folderu, zaznacz wszystko (**Ctrl+A**, razem z folderem `.github`) i przeciągnij na stronę. Kliknij **Commit changes**.

## 2. Sekrety

W repozytorium: **Settings → Secrets and variables → Actions → New repository secret**.

| Nazwa | Skąd | Kiedy |
| --- | --- | --- |
| `ANTHROPIC_API_KEY` | klucz `sk-ant-…` z Claude Console | od razu |
| `TELEGRAM_BOT_TOKEN` | token od @BotFather | od razu |
| `AWIN_FEED_URL` | Awin → Toolbox → Create-a-Feed (niżej) | gdy programy (np. SNIPES) Cię zaakceptują |
| `PINTEREST_APP_ID` | Pinterest Developers → My apps | po akceptacji dostępu Trial |
| `PINTEREST_APP_SECRET` | Pinterest Developers → My apps | po akceptacji dostępu Trial |

**Feed produktów z Awin:** Toolbox → Create-a-Feed → wybierz zaakceptowane programy → format standardowy Awin (nie Google) → kolumny „Select All” → CSV → skopiuj wygenerowany link i wklej jako `AWIN_FEED_URL`. Kilka linków możesz wkleić jeden pod drugim.

Bez feedu system i tak działa, ale robi piny tekstowe z linkiem do Twojej strony zamiast kolaży z produktami.

## 3. Start i test

1. Na Telegramie otwórz swojego bota i kliknij **Start**.
2. Na GitHubie: **Actions → Test → Run workflow**.
3. Po 2–3 minutach bot przyśle wynik testu i 2 przykładowe propozycje pinów.

Od tej chwili system działa sam:

| Co | Kiedy |
| --- | --- |
| Plan dnia i propozycje pinów | codziennie ok. 7:15 (zimą) |
| Sprawdzanie zatwierdzeń i publikacja | co godzinę |
| Raport tygodniowy | poniedziałek rano |

GitHub czasem uruchamia zaplanowane zadania z kilkunastominutowym opóźnieniem. To normalne.

## 4. Połączenie z Pinterestem

Gdy Pinterest zaakceptuje dostęp Trial i dodasz sekrety `PINTEREST_APP_ID` oraz `PINTEREST_APP_SECRET`:

1. **Actions → Połącz Pinterest → Run workflow** (env: `production`).
2. Bot przyśle link. Otwórz go zalogowany na konto **Girl's Style** i kliknij **Give access**.
3. Strona pokaże kod. Wyślij go botowi w ciągu 10 minut.
4. Bot potwierdzi, z jakim kontem się połączył. Jeśli to nie @GirlsStyle_, połącz jeszcze raz na właściwym koncie.

Do nagrania wideo dla Pinteresta (wniosek o dostęp Standard) uruchom to samo z env `sandbox`, a potem wyślij botowi `/tryb sandbox`.

## 5. Tryby publikacji

| Tryb | Co się dzieje po ✅ |
| --- | --- |
| `manual` (domyślny) | bot przysyła grafikę i teksty do skopiowania, wrzucasz sam |
| `sandbox` | publikacja przez API w trybie testowym, widoczna tylko dla Ciebie |
| `live` | publikuję sam o zaplanowanej godzinie (wymaga dostępu Standard) |

## Komendy na Telegramie

- `/status` – stan systemu
- `/plan` – dodatkowe propozycje teraz
- `/raport` – raport i analiza teraz
- `/tryb manual`, `/tryb sandbox`, `/tryb live`
- `/pomoc`

Przyciski i komendy są obsługiwane co godzinę, więc odpowiedź może przyjść z opóźnieniem.

## Ustawienia

Plik `config.json` (edytujesz go na GitHubie ikoną ołówka):

- `max_pins_per_day` – górny limit pinów dziennie (AI dobiera liczbę poniżej tego limitu),
- `publish_hours` – w jakich godzinach publikować,
- `trend_regions` – z jakich krajów brać trendy,
- `ai_model` – model AI.

## Koszty

- GitHub: 0 zł (mieści się w darmowych 2000 minutach miesięcznie dla prywatnego repozytorium).
- Telegram i Pinterest API: 0 zł.
- Claude: zwykle kilka dolarów miesięcznie. Limit ustawisz w Claude Console (workspace → Spend limits).

## Gdy coś nie działa

- Błędy system wysyła na Telegram (❗). Szczegóły są w **Actions** przy czerwonym przebiegu.
- „Bot nie zna Twojego czatu” – kliknij Start u bota i uruchom akcję jeszcze raz.
- Pinterest przestał działać po ok. 2 miesiącach bez uruchomień – uruchom „Połącz Pinterest” ponownie.

Dane: w `data/state.json` system trzyma tylko swoje szkice i ustawienia, a dostęp do Pinteresta jest zaszyfrowany. Statystyki Pinteresta są pobierane na bieżąco i nie są zapisywane.
